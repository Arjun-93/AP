package com.IIITD_AP_KR3;

//Q8: Convert the following cmplx class into a singleton class.
// You should be able to pass the values of real and imaginary components from the main function.

public class Main8 {
    public static void main(String[] args) {
        cmplx complexNumber = cmplx.getInstance(9.5,10.5);
        System.out.println(complexNumber);

        complexNumber = cmplx.getInstance(9.5,11.5);
        System.out.println(complexNumber);

        complexNumber = cmplx.getInstance(1,2);
        System.out.println(complexNumber);
    }
}

final class cmplx{
    private double re;
    private double im;
    private static cmplx complexInstance = null;
    private cmplx(double re, double im){
        this.re=re;
        this.im=im;
    }

    public static cmplx getInstance(double re, double im) {
        if (complexInstance == null){
            complexInstance = new cmplx(re,im);
        }
        else{
            complexInstance.re=re;
            complexInstance.im=im;
        }
        return complexInstance;
    }

    @Override
    public String toString() {
        return ""+ re + "+" + im +
                'i';
    }
}