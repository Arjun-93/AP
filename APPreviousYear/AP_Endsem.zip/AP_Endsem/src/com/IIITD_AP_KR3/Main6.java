package com.IIITD_AP_KR3;

//Q6: Modify A6 such that it implements the Comparable Interface. And compare a with b in terms of i-value in the main function.

public class Main6 {
    public static void main(String[] args) {
        A6 a=new A6(5);

        int result = a.compareTo(A6.getB());
        if (result<0)
            System.out.println("a.i < b.i");
        else if (result>0)
            System.out.println("a.i > b.i");
        else
            System.out.println("a.i == b.i");
    }
}

class A6 implements Comparable<A6>{
    private static A6 b;
    static{
        b=new A6(7);
    }

    private int i;
    public A6(int i){
        this.i=i;
    }

    public static A6 getB() {
        return b;
    }

    @Override
    public int compareTo(A6 o) {
        if (this.i>o.i)
            return 1;
        else if (this.i<o.i)
            return -1;
        else return 0;
    }
}