package com.IIITD_AP_KR3;

//Q4: Currently there is a composition relationship between A4 & B4.
// Mopdify this code in such a way that there is an association relationship between A4 & B4 and the program still prints 5.

public class Main4 {
    public static void main(String[] args) {
        //System.out.println((new B4()).a.i);

        A4 a = new A4();
        B4 b = new B4(a);
        System.out.println(b.getA().getI());

    }
}

class A4{
    private int i=5;

    public int getI() {
        return i;
    }
}

class B4{
    private A4 a;
    public B4(A4 a){
        this.a = a;
    }

    public A4 getA() {
        return a;
    }
}