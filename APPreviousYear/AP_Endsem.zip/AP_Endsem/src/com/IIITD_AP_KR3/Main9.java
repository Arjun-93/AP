package com.IIITD_AP_KR3;

//Q9: Create the list of 5 complex numbers (class=cmplx2) and print them all using an iterator in the main function.

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Main9 {
    public static void main(String[] args) {

        ArrayList<cmplx2> complexArrayList = new ArrayList<cmplx2>();
        complexArrayList.add(new cmplx2(2,3));
        complexArrayList.add(new cmplx2(4.2,3.5));
        complexArrayList.add(new cmplx2(5.1,10));
        complexArrayList.add(new cmplx2(6.3,37));
        complexArrayList.add(new cmplx2(9.9,7));

        System.out.println("Using Iterator :");
        Iterator<cmplx2> cmplx2Iterator = complexArrayList.iterator();
        while(cmplx2Iterator.hasNext()) {
            System.out.println(cmplx2Iterator.next());
        }

        System.out.println("\nUsing List Iterator in forward fashion:");
        ListIterator<cmplx2> cmplx2ListIterator = complexArrayList.listIterator();
        while(cmplx2ListIterator.hasNext()) {
            System.out.println(cmplx2ListIterator.next());
        }

        System.out.println("\nUsing List Iterator in backward fashion:");
        while(cmplx2ListIterator.hasPrevious()) {
            System.out.println(cmplx2ListIterator.previous());
        }

    }
}

class cmplx2{
    private double re;
    private double im;
    public cmplx2(double re, double im){
        this.re=re;
        this.im=im;
    }

    @Override
    public String toString() {
        return ""+ re + "+" + im + "i";
    }
}