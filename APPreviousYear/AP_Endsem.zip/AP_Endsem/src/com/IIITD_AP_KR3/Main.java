package com.IIITD_AP_KR3;

//Q1: Convert this code such that it does the same job but by implementing the Runnable interface

public class Main {
    public static void main(String[] args) {
	      th t1=new th(1);
	      th t2=new th(2);
          Thread thread1 = new Thread(t1);
          Thread thread2 = new Thread(t2);
          thread1.start();
          thread2.start();

    }
}

class th implements Runnable{
    private int i;
    public th(int i){
        this.i=i;
    }
    @Override
    public void run(){
        int j=0;
        for (j=1;j<1000;j++){
            System.out.println(i);
        }
    }
}